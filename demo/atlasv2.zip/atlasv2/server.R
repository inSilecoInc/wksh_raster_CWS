server <- function(input, output, session) {
  updateSelectInput(session, "species", choices = unique(cdqs$Espece.Species.EN))
  output$map <- renderLeaflet(
    {
      tmp <- cdqs %>% 
        filter(Espece.Species.EN == !!input$species) 
      leaflet(tmp) %>% 
      setView(lng = -63, lat = 48, zoom = 5) %>% 
      addProviderTiles("CartoDB.Positron") %>%
      addCircleMarkers(
        stroke = FALSE,
        popup = ~as.character(Nom.de.colonie.Colony.name))
    }
  )
}
library(sf)
library(dplyr)

# oad data
cdqs <- st_as_sf(x = read.csv('data/cdqs.csv'),
                 coords = c("CentroideX", "CentroideY"),
                 crs = 4326)
sl <- st_read("data/st_laurence.geojson")

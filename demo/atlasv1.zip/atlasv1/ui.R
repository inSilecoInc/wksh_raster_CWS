ui <- fluidPage(
  sidebarLayout(
    sidebarPanel(
      h1("Sidebar"),
      selectInput(inputId = "species", label = "Select species", choices = "placeholder")
      # input$species
    ),
    mainPanel(
      h1("Main Panel"),
      plotOutput("map", width = "100%")
    )
  )
)
server <- function(input, output, session) {
  updateSelectInput(session, "species", choices = unique(cdqs$Espece.Species.EN))
  output$map <- renderPlot({
    plot(st_geometry(sl), border = "grey50") 
    cdqs %>% 
    filter(Espece.Species.EN == !!input$species) %>% 
    st_geometry() %>%
    plot(add = TRUE, pch = 19)
  })
}
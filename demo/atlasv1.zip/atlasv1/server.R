server <- function(input, output, session) {
  cdqs <- st_as_sf(x = read.csv('data/cdqs.csv'),
                   coords = c("CentroideX", "CentroideY"),
                   crs = 4326)
  updateSelectInput(session, "species", choices = unique(cdqs$Espece.Species.EN))
  output$map <- renderPlot({
    plot(st_geometry(sl), border = "grey50") 
    cdqs %>% 
    filter(Espece.Species.EN == !!input$species) %>% 
    st_geometry() %>%
    plot(add = TRUE, pch = 19)
  })
}
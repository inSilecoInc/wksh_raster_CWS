library(sf)
library(dplyr)
library(leaflet)
library(mapedit)

cdqs <- st_as_sf(x = read.csv('data/cdqs.csv'),
                 coords = c("CentroideX", "CentroideY"),
                 crs = 4326)

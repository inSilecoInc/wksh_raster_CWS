server <- function(input, output, session) {
  updateSelectInput(session, "species", choices = unique(cdqs$Espece.Species.EN))
  observeEvent(input$species, {
    tmp <- cdqs %>% 
      filter(Espece.Species.EN == !!input$species) 
    map <- leaflet(tmp) %>% 
      setView(lng = -63, lat = 48, zoom = 5) %>% 
      addProviderTiles("CartoDB.Positron") %>%
      addCircleMarkers(
        stroke = FALSE,
        popup = ~as.character(Nom.de.colonie.Colony.name))
    edits <<- callModule(editMod, leafmap = map, id = "map")
  })
  observeEvent(input$save, {
    geom <- edits()$finished
    if (!is.null(geom)) {
       assign('new_geom', geom, envir = .GlobalEnv)
       sf::write_sf(geom, 'new_geom.geojson', delete_layer = TRUE, delete_dsn = TRUE)
     } # see https://github.com/r-spatial/mapedit/issues/95
   })
}